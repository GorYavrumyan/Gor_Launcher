import os
import sys
import json

from PyQt6.QtWidgets import (QApplication, QDialog, QVBoxLayout, QHBoxLayout,
                             QListWidget, QListWidgetItem, QSplitter, QWidget,
                             QLabel, QProgressBar, QMenu, QMessageBox)
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtCore import QUrl, Qt, QSize, QTimer
from PyQt6.QtGui import QIcon, QShortcut, QKeySequence, QDesktopServices

from style_loader import apply_global_style


ERROR_PAGE_TEMPLATE = """
<html>
<head>
<style>
    body {{
        background-color: #0a0a0a;
        color: #f0f0f0;
        font-family: 'Segoe UI', Arial, sans-serif;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
    }}
    .box {{
        text-align: center;
        border: 1px solid #333;
        background-color: #141414;
        border-radius: 12px;
        padding: 40px 60px;
    }}
    .icon {{ font-size: 48px; margin-bottom: 16px; }}
    .title {{ color: #e74c3c; font-size: 20px; font-weight: bold; margin-bottom: 10px; }}
    .msg {{ color: #ccc; font-size: 14px; }}
</style>
</head>
<body>
    <div class="box">
        <div class="icon">⚠️</div>
        <div class="title">Не удалось загрузить аддон</div>
        <div class="msg">{message}</div>
    </div>
</body>
</html>
"""

EMPTY_PAGE = """
<html>
<head>
<style>
    body {
        background-color: #0a0a0a;
        color: #666;
        font-family: 'Segoe UI', Arial, sans-serif;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        font-size: 16px;
    }
</style>
</head>
<body>
    <div>⬅️ Выберите аддон слева, чтобы открыть его интерфейс</div>
</body>
</html>
"""


class ControlCenter(QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("GOR Control Center - Управление аддонами")
        self.resize(1100, 720)

        self.current_addon_path = None   # путь к папке текущего аддона
        self.current_web_path = None      # путь к index.html текущего аддона
        self.current_item = None

        # Оформление берётся из общего style.qss, применяется глобально
        # к QApplication в блоке __main__ (см. style_loader.py).

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Сплиттер для разделения списка и веб-интерфейса
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(6)
        splitter.setChildrenCollapsible(False)

        # --- 1. Список аддонов ---
        self.addon_list = QListWidget()
        self.addon_list.setObjectName("AddonList")
        self.addon_list.setMinimumWidth(220)
        self.addon_list.setMaximumWidth(320)
        self.addon_list.setIconSize(QSize(32, 32))
        self.addon_list.itemClicked.connect(self.load_addon_web)
        self.addon_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.addon_list.customContextMenuRequested.connect(self.show_context_menu)

        # --- 2. Правая часть: статус-бар загрузки + веб-интерфейс ---
        right_container = QWidget()
        right_layout = QVBoxLayout(right_container)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        self.status_bar = QWidget()
        self.status_bar.setObjectName("StatusBar")
        status_layout = QHBoxLayout(self.status_bar)
        status_layout.setContentsMargins(12, 6, 12, 6)
        status_layout.setSpacing(10)

        self.status_label = QLabel("Готов")
        self.status_label.setObjectName("StatusLabel")
        status_layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setObjectName("LoadProgress")
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)
        status_layout.addWidget(self.progress_bar, stretch=1)

        right_layout.addWidget(self.status_bar)

        self.web_view = QWebEngineView()
        self.web_view.loadStarted.connect(self.on_load_started)
        self.web_view.loadProgress.connect(self.on_load_progress)
        self.web_view.loadFinished.connect(self.on_load_finished)
        self.web_view.setHtml(EMPTY_PAGE)
        right_layout.addWidget(self.web_view, stretch=1)

        splitter.addWidget(self.addon_list)
        splitter.addWidget(right_container)
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([260, 840])

        layout.addWidget(splitter)

        # --- Горячая перезагрузка F5 ---
        self.reload_shortcut = QShortcut(QKeySequence("F5"), self)
        self.reload_shortcut.activated.connect(self.reload_current_page)

        self.scan_addons()

    # ------------------------------------------------------------------
    # Сканирование аддонов (логика сохранена без изменений)
    # ------------------------------------------------------------------
    def scan_addons(self):
        """Сканирует addons и синхронизируется с games_data.json"""
        base_path = os.path.dirname(os.path.abspath(sys.argv[0]))
        addons_dir = os.path.join(base_path, "addons")
        data_path = os.path.join(base_path, "games_data.json")

        # Загружаем список из файла лаунчера
        active_addons = []
        if os.path.exists(data_path):
            try:
                with open(data_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    active_addons = data.get("addons_list", [])
            except Exception:
                pass

        if not os.path.exists(addons_dir):
            return

        for folder in os.listdir(addons_dir):
            addon_path = os.path.join(addons_dir, folder)
            config_path = os.path.join(addon_path, "config.json")
            web_path = os.path.join(addon_path, "web", "index.html")
            icon_path = os.path.join(addon_path, "favicon.png")

            # Проверяем структуру и наличие в списке активных
            if os.path.exists(config_path) and os.path.exists(web_path):
                try:
                    with open(config_path, 'r', encoding='utf-8') as f:
                        config = json.load(f)

                    name = config.get("name", folder)

                    # Проверяем, есть ли аддон в списке разрешенных из json
                    if folder in active_addons or name in active_addons:
                        item = QListWidgetItem(name)
                        if os.path.exists(icon_path):
                            item.setIcon(QIcon(icon_path))

                        item.setData(Qt.ItemDataRole.UserRole, web_path)
                        item.setData(Qt.ItemDataRole.UserRole + 1, addon_path)
                        self.addon_list.addItem(item)
                except Exception:
                    continue

    # ------------------------------------------------------------------
    # Загрузка веб-интерфейса аддона
    # ------------------------------------------------------------------
    def load_addon_web(self, item):
        web_path = item.data(Qt.ItemDataRole.UserRole)
        addon_path = item.data(Qt.ItemDataRole.UserRole + 1)

        self.current_item = item
        self.current_web_path = web_path
        self.current_addon_path = addon_path

        self._load_path(web_path)

    def _load_path(self, web_path):
        if not web_path or not os.path.exists(web_path):
            self.show_error_page(
                f"Файл index.html не найден по пути:<br><code>{web_path}</code>"
            )
            return

        try:
            self.web_view.setUrl(QUrl.fromLocalFile(web_path))
        except Exception as e:
            self.show_error_page(f"Ошибка при загрузке страницы: {e}")

    def show_error_page(self, message):
        self.status_label.setText("Ошибка загрузки")
        self.progress_bar.setVisible(False)
        self.web_view.setHtml(ERROR_PAGE_TEMPLATE.format(message=message))

    # ------------------------------------------------------------------
    # Индикатор загрузки
    # ------------------------------------------------------------------
    def on_load_started(self):
        self.status_label.setText("Загрузка...")
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)

    def on_load_progress(self, value):
        self.progress_bar.setValue(value)

    def on_load_finished(self, ok):
        self.progress_bar.setVisible(False)
        if ok:
            self.status_label.setText("Готово")
            # Через пару секунд возвращаем нейтральный статус
            QTimer.singleShot(2000, lambda: self.status_label.setText("Готов"))
        else:
            self.show_error_page(
                "Аддон не смог загрузиться. Проверьте, что файл index.html "
                "не повреждён и все ресурсы (JS/CSS) находятся на месте."
            )

    # ------------------------------------------------------------------
    # Горячая перезагрузка F5
    # ------------------------------------------------------------------
    def reload_current_page(self):
        if self.current_web_path:
            self.status_label.setText("Перезагрузка...")
            self._load_path(self.current_web_path)
        else:
            self.web_view.reload()

    # ------------------------------------------------------------------
    # Контекстное меню списка аддонов
    # ------------------------------------------------------------------
    def show_context_menu(self, pos):
        item = self.addon_list.itemAt(pos)
        if item is None:
            return

        menu = QMenu(self)
        reload_action = menu.addAction("🔄 Перезагрузить страницу")
        open_folder_action = menu.addAction("📁 Открыть папку аддона")

        action = menu.exec(self.addon_list.mapToGlobal(pos))

        if action == reload_action:
            # Если кликнули не по текущему выбранному - сначала загружаем его
            if item is not self.current_item:
                self.addon_list.setCurrentItem(item)
                self.load_addon_web(item)
            else:
                self.reload_current_page()

        elif action == open_folder_action:
            addon_path = item.data(Qt.ItemDataRole.UserRole + 1)
            self.open_addon_folder(addon_path)

    def open_addon_folder(self, addon_path):
        if not addon_path or not os.path.exists(addon_path):
            QMessageBox.warning(
                self, "Папка не найдена",
                f"Папка аддона не найдена:\n{addon_path}"
            )
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(addon_path))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    apply_global_style(app)
    window = ControlCenter()
    window.show()
    sys.exit(app.exec())